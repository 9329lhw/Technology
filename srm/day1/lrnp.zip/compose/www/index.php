<?php
$redis = new Redis();
$redis->connect('172.100.100.130', 6379);//serverip port
$redis ->set("test" , "Hello World");
echo $redis ->get("test");
